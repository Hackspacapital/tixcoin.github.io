<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<title>CryptoBridge - Decentralized Cryptocurrency Exchange</title>
	<meta content="" name="description">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<meta content="all,follow" name="robots">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="css/themify-icons.css" rel="stylesheet">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.default.css" id="theme-stylesheet" rel="stylesheet">
	<link href="favicon.ico" rel="shortcut icon">
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<link href="/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180">
	<link href="/favicon-32x32.png" rel="icon" sizes="32x32" type="image/png">
	<link href="/favicon-16x16.png" rel="icon" sizes="16x16" type="image/png">
	<link href="/manifest.json" rel="manifest">
	<link color="#5bbad5" href="/safari-pinned-tab.svg" rel="mask-icon">
	<meta content="#ffffff" name="theme-color">
	<link href="//cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/normalize.css" />
	<link rel="stylesheet" type="text/css" href="css/component.css" />
	<script src="//platform-api.sharethis.com/js/sharethis.js#property=59db1f00be590e00122886ad&product=sticky-share-buttons" type="text/javascript">
	</script>
</head>
<body data-offset="120" data-spy="scroll" data-target="#navigation">
	<!--<div class="language-switch">
		<ul>
			<li>
				<a class="active" href="#">EN</a>
			</li>
			<li>
				<a href="#">CN</a>
			</li>
		</ul>
	</div>-->
	<!-- navbar-->
    <header class="header">
      <div class="sticky-wrapper">
        <div role="navigation" class="navbar navbar-default">
          <div class="container">
            <div class="navbar-header">
              <button type="button" data-toggle="collapse" data-target=".navbar-collapse" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a href="index.php" class="navbar-brand scroll-to"><img src="img/logo.png" alt="" width="50"></a>
            <p class="btn-xs" style="width: 12em;"><b>$BCO price</b><br /><a href="https://wallet.crypto-bridge.org" target="_blank">0.00022079 BTC</a>
			</div>
            <div id="navigation" class="collapse navbar-collapse">
              <style>
@media screen and (max-width: 1920px) {
  .nav.navbar-nav.navbar-right {
  .display: none;}
}
						</style>
				<ul class="nav navbar-nav navbar-right">
                <li><a href="#about">About</a></li>
                <li><a href="#news">News</a></li>
                <li><a href="#download">Download</a></li>
                <li><a href="https://medium.com/@cryptobridge" target="_new">Blog</a></li>
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#roadmap">Roadmap</a></li>
                <li><a href="#support">Support</a></li>
             <li><a href="addcoin.php">Add coin</a></li>

                <li><a href="#contact">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- /.navbar-->
	
	<section class="section-gray" id="roadmap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2 class="heading">Add a coin</h2>
				</div>
	
				<div class="row">
					<div class="col-md-12">

<h6>Please use this form to request a new coin listing on the CryptoBridge Decentralised Exchange.</h6>

There is a 1 BTC standard listing fee and a 3 BTC fast-track option. <br/>

<h5>Fast-track</h4>
We aim to get you live within 24hrs from confirmed payment, we will contact you within 12 hrs of request.<br/>

<h5>Standard</h5>
Generally 7-12 days from request to listing, but can vary depending on demand at the time. We will aim to contact you within 7 days of request being lodged.
<br/><br/>

<b>Please be sure to give at least 1 WEEK notice of any fork or fundamental change to the coin's chain.</b><br/>
<br/><br/>

<h5>Any update within 1 month of listing or 1 month of a previous update will incur the below fees:</h5>

<b>WALLET UPDATE:   0.25  BTC</b><br/>
<b>FORK/SWAP:                        0.5    BTC</b></br>
<br/><br/>

If your daemon source code produces any kind of financial damage to CryptoBridge by malfunctioning or containing serious bugs, you agree to fully compensate for all damage. We compile from the LATEST OFFICIAL RELEASE of your github.<br/><br/>

Please make your ticker is NOT already listed at <a href="https://coinmarketcap.com/all/views/all/" target="_new">CMC</a> that does not represent your coin.<br></br>

CryptoBridge have a minimum daily volume threshold of 0.25 BTC/day, averaged over 30 days. If the threshold is not met for 3 consecutive months we may delist your coin. (You will be given a warning at 2 months)<br/><br/>

NOTE: We do not currently support, ETH based chains (or tokens), NEO (or tokens), GAS or Cryptonight coins. These are all in development and will be announced when available.<br/><br/>

<h5>NOTE: Due to recent security concerns we will ONLY issue you a payment address via discord. Please join our discord server on link below and be sure you are talking to someone from the team</h5>
<b>Dev</b><br/>
crypto#5644       ID 398376742135529472<br/>
bridge#1330       ID 182490821998804993<br/>

<b>BridgeKeeper</b><br/><br/>
CoinMan#6504     ID 399893443704258582<br/>
sherlock-holmes#7421 - ID 402476479767773185<br/>

<hr/>
					</div>
				</div>

                <h3>FORM</h3>
                <form method="POST" action="request_coin.php" id="addCoin">
                    <div class="addCoin" style="max-width: 500px;">
                        <div class="form-group">
                            <label for="formType">Is it a token or coin?</label>
                            <select name="type" class="form-control" id="formType">
                                <option value="coin">Coin</option>
                                <option value="token">Token</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formName">Coin Name</label>
                            <input name="name" size="40" type="text" class="form-control" id="formName">
                        </div>

                        <div class="form-group">
                            <label for="formBaseChain">Which base chain is your coin/token on (if applicable, e.g ETH)</label>
                            <input name="basechain" size="40" class="form-control" id="formBaseChain">
                        </div>

                        <div class="form-group">
                            <label for="formFork">Which coin are you forked/cloned from (with version number)</label>
                            <input name="fork" size="40" class="form-control" id="formFork">
                        </div>

                        <div class="form-group">
                            <label for="formTicker">Official Coin Ticker (e.g BCO). If you're not on CMC it may not be an existing ticker with the same name.</label>
                            <input name="ticker" size="40" class="form-control" id="formTicker">
                        </div>

                        <div class="form-group">
                            <label for="formSource">Github source link. We require a github release. Needs to start with http:// or https://</label>
                            <input name="source" size="40" class="form-control" id="formSource">
                        </div>

                        <div class="form-group">
                            <label for="formCmc">CoinMarketCap page (if applicable)</label>
                            <input name="cmc" size="40" class="form-control" id="formCmc">
                        </div>

                        <div class="form-group">
                            <label for="formBitcointalk">BitcoinTalk ANN Page (if no CMC above)</label>
                            <input name="bitcointalk" size="40" class="form-control" id="formBitcointalk">
                        </div>

                        <div class="form-group">
                            <label for="formTwitter">Official Twitter handle</label>
                            <input name="twitter" size="40" class="form-control" id="formTwitter">
                        </div>

                        <div class="form-group">
                            <label for="formLogo">Link to Logo, (minimum 200x200px, transparent PNG required). Needs to start with http:// or https://</label>
                            <input name="logo" size="40" class="form-control" id="formLogo">
                        </div>

                        <div class="form-group">
                            <label for="formSupply">MAXIMUM supply as an absolute number (e.g 1000000). This is important for precision. If unlimited, provide calculated maximum supply in 5 years. </label>
                            <input name="supply" size="40" class="form-control" id="formSupply">
                        </div>

                        <div class="form-group">
                            <label for="formListingFee">Which listing fee option, in BTC, are you requesting (standard, instant or other)</label>
                            <select name="listing_fee" class="form-control" id="formListingFee">
                                <option>1 BTC standard listing</option>
                                <option>3 BTC fast-track listing</option>
                                <option>Other</option>
                            </select>
                            <input name="other" size="40" class="form-control" id="formListingFeeOther" placeholder="Please specify" style="margin-top:5px;display:none">
                        </div>

                        <div class="form-group">
                            <label for="formDiscord">Your contact username on discord, please join ours <a target="_new" href="https://discord.gg/wDxqDQm">https://discord.gg/wDxqDQm</a></label>
                            <input name="discord" size="40" class="form-control" id="formDiscord">
                        </div>


                        <div class="form-group">
                            <label for="formEmail">Your email address</label>
                            <input name="email" size="40" class="form-control" id="formEmail">
                        </div>


                        <div class="form-group">
                            <label for="formUnderstand">You need to verify manually that the payment request comes from one of the following persons (crypto#5644 ID 398376742135529472, sherlock-holmes#7421 402476479767773185, bridge#1330 182490821998804993, CoinMan#6504 399893443704258582) as there are scammers claiming to be from CryptoBridge. Do not send coins to an address that is not provided by the above persons. Please type in "I UNDERSTAND"</label>
                            <input name="understand" size="40" class="form-control" id="formUnderstand">
                        </div>

                        <button type="submit" class="btn btn-default">Submit coin request</button>
                    </div>
                </form>

			</div>
		</div>
	</section>
	<footer class="section-blue">
		<div class="container">
			<div class="row copyright">
				<div class="col-md-6">
					<p class="roboto">&copy;2017-2018 Crypto-Bridge.org</p>
				</div>
				<div class="col-md-6">
					<!--<p class="credit roboto"><a href="#">EN</a> | <a href="#">CN</a></p>-->
				</div>
			</div>
		</div>
	</footer>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js">
	</script> 
	<script>
	      window.jQuery || document.write('<script src="js/jquery-1.11.0.min.js"><\/script>')
	</script> 
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js">
	</script> 
	<script src="js/jquery.sticky.js">
	</script> 
	<script src="js/jquery.scrollTo.min.js">
	</script> 
	<script src="js/jquery.cookie.js">
	</script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js">
    </script>
    <script>
        $.validator.setDefaults({
            submitHandler: function (form) {
                form.submit();
            }
        });

        $.validator.methods.understand = function(value, element) {
            return this.optional(element) || value === "I UNDERSTAND";
        };

        $(document).ready( function () {

            $("#formListingFee").change(function() {
                $("#formListingFeeOther").toggle($("#formListingFee").val() === "Other");
            });

            $("#addCoin").validate({
                rules: {
                    type: "required",
                    name: "required",
                    ticker: "required",
                    source: {
                        required: true,
                        url: true
                    },
                    cmc: {
                        required: false,
                        url: true
                    },
                    bitcointalk: {
                        required: false,
                        url: true
                    },
                    twitter: "required",
                    logo: {
                        required: true,
                        url: true
                    },
                    supply: {
                        required: true,
                        number: true
                    },
                    listing_fee: "required",
                    other: {
                        required: true,
                        depends: function() {
                            return $("#formListingFee").val() === "Other";
                        }
                    },
                    discord: "required",
                    email: {
                        required: true,
                        email: true
                    },
                    understand: {
                        required: true,
                        understand: true
                    }
                },
                messages: {
                    type: "Please select the coin type",
                    name: "Please provide the coin name",
                    ticker: "Please enter the ticker name",
                    source: "Please enter a valid github url",
                    cmc: "Please enter a valid url for CoinMarketCap",
                    bitcointalk: "Please enter a valid url",
                    twitter: "Twitter is required",
                    logo: "Please enter a valid logo image url",
                    supply: "Please enter the maximum supply (number)",
                    listing_fee: "Please select the listing fee type",
                    other: "Please specify",
                    discord: "Please add your discord name",
                    email: "Please enter a valid email address",
                    understand: "Please write I UNDERSTAND"
                },
                errorElement: "em",
                errorPlacement: function (error, element) {
                    error.addClass("help-block");
                    error.insertAfter(element);
                },
                highlight: function (element) {
                    $(element).parents(".form-group").addClass("has-error").removeClass("has-success");
                },
                unhighlight: function (element) {
                    $(element).parents(".form-group").addClass("has-success").removeClass("has-error");
                }
            })
        });
    </script>

	<script>
	             jQuery( '#navbar-toggle' ).on( 'click', function(e){
	                 jQuery( '#navigation' ).toggleClass( "in" );
	             });
				 
				 jQuery( '.navbar-nav a' ).on( 'click', function(e){
	                 jQuery( '#navigation' ).toggleClass( "in" );
	             });

var offset = $('.navbar').offset().top;
$('.header .sticky-wrapper').height($('.navbar').height());

$(window).scroll(function () {
  if ( $(this).scrollTop() > offset && !$('header').hasClass('fix') ) {
    $('.navbar').addClass('fix');
	$('.overlay').hide();
   } else if ( $(this).scrollTop() <= offset ) {
    $('.navbar').removeClass('fix');
	$('.overlay').show();
  }
});
	</script>
</body>
</html>
